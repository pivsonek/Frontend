﻿namespace project;

/// <summary>
/// Definuje strukturu navigace aplikace.
/// </summary>
public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
    }
}
